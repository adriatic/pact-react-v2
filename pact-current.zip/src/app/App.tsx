import React, { useEffect, useState } from "react";

type Event =
  | { type: "cellStarted"; cellId: string; parentId?: string; label?: string }
  | { type: "cellStream"; cellId: string; chunk: string }
  | { type: "cellCompleted"; cellId: string }
  | { type: "cellError"; cellId: string; error: string };

type Cell = {
  id: string;
  parentId?: string;
  label?: string;
  response: string;
  status?: string;
};

declare const acquireVsCodeApi: any;
const vscode = acquireVsCodeApi();

export default function App() {
  const [cells, setCells] = useState<Record<string, Cell>>({});
  const [prompt, setPrompt] = useState("");

  function run() {
    vscode.postMessage({
      type: "RUN_REQUESTED",
      prompt,
    });
  }

  function retry(cellId: string) {
    vscode.postMessage({
      type: "RETRY_CELL",
      cellId,
    });
  }

  useEffect(() => {
    const handler = (event: MessageEvent) => {
      const data: Event = event.data;

      switch (data.type) {
        case "cellStarted":
          setCells((prev) => ({
            ...prev,
            [data.cellId]: {
              id: data.cellId,
              parentId: data.parentId,
              label: data.label,
              response: "",
              status: "running",
            },
          }));
          break;

        case "cellStream":
          setCells((prev) => ({
            ...prev,
            [data.cellId]: {
              ...prev[data.cellId],
              response: (prev[data.cellId]?.response || "") + data.chunk,
            },
          }));
          break;

        case "cellCompleted":
          setCells((prev) => ({
            ...prev,
            [data.cellId]: {
              ...prev[data.cellId],
              status: "done",
            },
          }));
          break;

        case "cellError":
          setCells((prev) => ({
            ...prev,
            [data.cellId]: {
              ...prev[data.cellId],
              status: "error",
            },
          }));
          break;
      }
    };

    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  return (
    <div style={{ padding: 20, fontFamily: "monospace" }}>
      <h2>PACT</h2>

      {/* Run Panel */}
      <div style={{ marginBottom: 20 }}>
        <input
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Enter prompt"
          style={{ width: "70%", marginRight: 10 }}
        />
        <button onClick={run}>Run</button>
      </div>

      {/* Cells */}
      <div>
        {Object.values(cells).map((cell) => (
          <div
            key={cell.id}
            style={{
              border: "1px solid #888",
              padding: 10,
              marginBottom: 10,
            }}
          >
            <div>
              <strong>{cell.label || "GPT"}</strong>
            </div>

            <pre>{cell.response}</pre>

            {cell.status === "done" && (
              <button onClick={() => retry(cell.id)}>Retry</button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}