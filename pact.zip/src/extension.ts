import * as vscode from "vscode";

export function activate(context: vscode.ExtensionContext) {
  console.log("=== ACTIVATE CALLED ===");

  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider("pact.controlPanel", {
      resolveWebviewView(webviewView: vscode.WebviewView) {
        console.log("=== VIEW RESOLVED ===");

        webviewView.webview.options = {
          enableScripts: true,
        };

        webviewView.webview.html = `
          <html>
            <body>
              <h1>WORKING</h1>
            </body>
          </html>
        `;
      },
    })
  );
}

export function deactivate() {}